#!/usr/bin/env bash
# S7S.AI — s7s عقارات: «اللمسات الأخيرة»
#   - لوحة تحكم تفاعلية جديدة (مؤشرات متحركة، رسم إيراد/مصروف، نسبة التحصيل، الإشغال، المطلوب اليوم + واتساب)
#   - زر «عبّي بيانات تجريبية» للعرض + «امسح البيانات التجريبية»
#   - القائمة الجانبية ثابتة على الكمبيوتر + ترتيب أعمدة جدول الوحدات
#   bash update.sh              تركيب
#   bash update.sh --rollback   يرجّع زي ما كان
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SEARCH="${SEARCH:-/var/www}"; BKROOT="${BKROOT:-/root/s7s-backups}"; SITE="${SITE:-https://s7sai.cloud}"
EXPECT_OLD="079a836d5ceb238d1f35103fd7ca3f9f7882f692a843d23d675738b43e68870b"
EXPECT_NEW="5a676bfe4cfbc68f7b563ff37499cbf9022a6c39296ecf789b445fe27931e30f"
[ "$(id -u)" -eq 0 ] || { echo "شغّله كـ root"; exit 1; }

if [ "${1:-}" = "--rollback" ]; then
  B=$(ls -d "$BKROOT"/aqar-ui-* 2>/dev/null | sort | tail -1) || true
  [ -n "${B:-}" ] && [ -f "$B/dir.txt" ] || { echo "ما فيه نسخة أرجّعها"; exit 1; }
  D=$(cat "$B/dir.txt")
  cat "$B/index.html" > "$D/index.html"
  mv "$B" "$BKROOT/rolledback-$(basename "$B")"
  echo "تمّ — رجع نظام العقارات زي ما كان."; exit 0
fi

echo "== ١) فحص =="
mapfile -t APIS < <(grep -RlsF --include=index.php "case 'POST auth/register'" $SEARCH 2>/dev/null | xargs -r grep -lF "org_name" | xargs -r -n1 readlink -f | sort -u)
[ "${#APIS[@]}" -eq 1 ] || { echo "✗ لقيت ${#APIS[@]} نظام عقارات — وقفت بدون تعديل. أرسل هذا لرشيد."; printf '   %s\n' "${APIS[@]}"; exit 1; }
D="$(dirname "$(dirname "${APIS[0]}")")"; F="$D/index.html"
[ -f "$F" ] && grep -qF 'auth/register",f)' "$F" || { echo "✗ ما لقيت صفحة النظام في $D — وقفت"; exit 1; }
CUR=$(sha256sum "$F" | cut -c1-64)
if [ "$CUR" = "$EXPECT_NEW" ]; then echo "   ✓ التحديث مركّب من قبل"; exit 0; fi
[ "$CUR" = "$EXPECT_OLD" ] || { echo "✗ صفحة النظام في السيرفر تختلف عن النسخة اللي اشتغلت عليها — وقفت بدون تعديل. أرسل هذا لرشيد."; echo "   $CUR"; exit 1; }
echo "   ✓ نظام العقارات: $D"

echo "== ٢) نسخة احتياطية =="
BK="$BKROOT/aqar-ui-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BK"; chmod 700 "$BK"
cp -p "$F" "$BK/index.html"; echo "$D" > "$BK/dir.txt"
echo "   ✓ $BK"

echo "== ٣) تركيب =="
cat "$HERE/files/index.html" > "$F"
[ "$(sha256sum "$F" | cut -c1-64)" = "$EXPECT_NEW" ] || { echo "✗ الملف ما انكتب صح — أرجّع"; cat "$BK/index.html" > "$F"; exit 1; }
echo "   ✓ index.html"

echo "== ٤) فحص من برا =="
sleep 2
ok=1
if curl -fsS -m 25 "$SITE/s7saqat/index.html?v=$(date +%s)" | grep -F 's7d-css' >/dev/null; then echo "   ✓ الواجهة الجديدة ظاهرة"; else echo "   … الصفحة ما بانت للحين (ممكن كاش Cloudflare — تبان بعد دقايق)"; fi
if curl -fsS -m 25 "$SITE/s7saqat/api/index.php?r=ping" | grep -F '"ok":true' >/dev/null; then echo "   ✓ API العقارات شغّال"; else echo "   ✗ API ما رد"; ok=0; fi
echo
if [ "$ok" = 1 ]; then echo "تمّ ✅  الواجهة الجديدة جاهزة للعرض. سوّ تحديث للصفحة (Ctrl+Shift+R)."
else echo "تمّ مع ملاحظة ⚠️ — أرسل الكلام لرشيد. (البيانات ما تأثرت)"; fi
echo "للتراجع: bash $HERE/update.sh --rollback"
